export function Pie() {
  const anioActual = new Date().getFullYear()

  return (
    <footer>
      <p>© {anioActual} - Departamento de Informática</p>
    </footer>
  )
}