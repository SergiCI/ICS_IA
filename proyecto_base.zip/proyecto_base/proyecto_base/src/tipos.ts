// APARTADO 1 · Tipos
// Escribe aquí los tipos `Nota` y `Resultado` (consulta el enunciado).

export type Nota = {
    id : number;
    modulo : string;
    calificación : number;
    observaciones? : string | undefined;
};

export type Resultado = 'Suspenso' | 'Aprobado' | 'Notable' | 'Sobresaliente'