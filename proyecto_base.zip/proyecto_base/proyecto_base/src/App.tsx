// APARTADOS 4 y 5 · Estado, lista de notas y uso de los componentes.
// Ahora solo muestra el título. Importa lo que necesites desde `./datos`, `./tipos`,
// `./utilidades` y `./components`.

import { useState } from "react";
import { notasIniciales } from "./datos.ts";
import type { Nota } from "./tipos.ts";
import { ResumenNotas } from "./components/ResumenNotas.tsx";
import { FormularioNota } from "./components/FormularioNota.tsx";
import calcularResultado from "./utilidades.ts";

function App() {
  const [notas, setNotas] = useState<Nota[]>(notasIniciales);

  const total = notasIniciales.reduce((total, nota) => total + nota.calificacion, 0)

  function aprobadas(notasIniciales: Nota) {
    return calcularResultado(notasIniciales.calificación)
  }
  function media(notasIniciales: Nota) {
    if (notasIniciales === undefined) {
      return 0
    }
  }
  function anadirNota(nuevaNota: Nota) {
    setNotas((prevNotas) => [...prevNotas, nuevaNota]);
  }

  return (
    <main className="contenedor">
      <h1>Registro de notas</h1>
      <p className="subtitulo">2.º DAW · Evaluación final</p>
      {/* {notas.length === 0 ? (
        <p className="vacio">Todavía no hay notas registradas.</p>
      ) : (
        <div>
          {notas.map((notas) => (
            <ResumenNotas
              titulo="Resumen del Curso"
              media={ }
              aprobadas={aprobadas(notas)}
              total={total}
            />
            <ul className="lista-notas">
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ul>
          ))}
        </div>
      )} */}

      { }
      <FormularioNota alAnadir={anadirNota} />
    </main>
  )
}

export default App;
